<?php
require_once('config.php');
$conexion = obtenerConexion();

$idClase = $_GET['idClase'];  

$sql = "SELECT * FROM clases WHERE id = '$idClase'";
$result = $conexion->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode($row);  
} else {
    echo json_encode(["error" => "Clase no encontrada"]);
}

$conexion->close();
?>
