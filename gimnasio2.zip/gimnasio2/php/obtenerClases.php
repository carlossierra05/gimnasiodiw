<?php
require_once('config.php');
$conexion = obtenerConexion();

$query = "SELECT id_clase, tipo FROM clases";
$result = $mysqli->query($query);

if ($result) {
    $clases = [];
    while ($row = $result->fetch_assoc()) {
        $clases[] = $row;  
    }
    echo json_encode($clases);  
} else {
    echo json_encode([]);  
}

$mysqli->close();
?>