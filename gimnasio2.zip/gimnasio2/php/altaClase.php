<?php
include_once("config.php");
$conexion = obtenerConexion();

$tipo = $_POST['tipo'];
$horario = $_POST['horario'];
$idEntrenador = $_POST['idEntrenador'];
$sala = $_POST['sala'];

$sql = "INSERT INTO clases (tipo, horario, idEntrenador, sala) VALUES ('$tipo', '$horario', '$idEntrenador', '$sala')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => "Clase añadida correctamente"]);
} else {
    echo json_encode(["error" => "Error al añadir la clase"]);
}

$conn->close();
?>
