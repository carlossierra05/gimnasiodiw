<?php
include_once("config.php");
$conexion = obtenerConexion();

// Recoger datos JSON
$clase = json_decode($_POST['clase']);

$sql = "INSERT INTO clase VALUES ('$clase->id_clase',$clase->tipo,'$clase->horario',$clase->id_entrenador,'$clase->sala');";

mysqli_query($conexion, $sql);

if (mysqli_errno($conexion) != 0) {
    $numerror = mysqli_errno($conexion);
    $descrerror = mysqli_error($conexion);

    // Prototipo responder($datos,$ok,$mensaje,$conexion)
    responder(null, false, "Se ha producido un error número $numerror que corresponde a: $descrerror <br>", $conexion);

} else {
    // Prototipo responder($datos,$ok,$mensaje,$conexion)
    responder(null, true, "Se ha insertado la clase", $conexion);
}
$conexion->close();

?>
