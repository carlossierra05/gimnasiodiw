<?php
require_once('config.php');
$conexion = obtenerConexion();

$idClase = $_POST['idClase'];  

$sql = "DELETE FROM clases WHERE id = '$idClase'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => "Clase eliminada correctamente"]);
} else {
    echo json_encode(["error" => "Error al eliminar la clase"]);
}

$conn->close();
?>
