<?php
require_once('config.php');
$conexion = obtenerConexion();

// Recoger datos de entrada
$idClase = $_POST['id_clase'];

// SQL
$sql = "DELETE FROM clase WHERE id_clase = $idClase;";

$resultado = mysqli_query($conexion, $sql);

if (mysqli_errno($conexion) != 0) {
    $numerror = mysqli_errno($conexion);
    $descrerror = mysqli_error($conexion);

    // Prototipo responder($datos,$ok,$mensaje,$conexion)
    responder(null, true, "Se ha producido un error número $numerror que corresponde a: $descrerror <br>", $conexion);

} else {
    // responder(datos, error, mensaje, conexion)
    responder(null, false, "Clase borrada", $conexion);
}
$conexion->close();
?>