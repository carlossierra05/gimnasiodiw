<?php
require_once('config.php');
$conexion = obtenerConexion();

// Recupero las fechas de inicio y fin desde el GET
$fechaInicio = $_GET['fechaInicio'];
$fechaFin = $_GET['fechaFin'];

// SQL para recuperar los turismos entre las fechas proporcionadas
$sql = "SELECT entrenadores.dni, 
                entrenadores.enfoques, 
                entrenadores.nombre, 
                entrenadores.edad, 
                entrenadores.fecha_nacimiento, 
                (SELECT GROUP_CONCAT(salas.sala SEPARATOR ', ')
                 FROM salas 
                 WHERE id IN (SELECT id_sala 
                                from entrenadores_salas 
                                where entrenadores_salas.dni_entrenador = entrenadores.dni
                             )
                ) AS 'salas',
                (SELECT GROUP_CONCAT(especialidades.especialidad SEPARATOR ', ')
                 FROM especialidades 
                 WHERE id IN (SELECT id_especialidad 
                                from entrenadores_especialidades 
                                where entrenadores_especialidades.dni_entrenador = entrenadores.dni
                             )
                ) AS 'especialidades'
        FROM entrenadores
        WHERE entrenadores.fecha_nacimiento BETWEEN '$fechaInicio' AND '$fechaFin'
        ORDER BY entrenadores.fecha_nacimiento ASC";

$resultado = mysqli_query($conexion, $sql);

// Inicialización del array vacío
$datos = [];

while ($fila = mysqli_fetch_assoc($resultado)) {
    $datos[] = $fila; // Insertar la fila en el array
}

// parámetros: $datos, $ok, $mensaje, $conexion
responder($datos, true, "Datos recuperados", $conexion);