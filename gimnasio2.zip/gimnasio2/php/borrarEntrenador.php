<?php
require_once('config.php');
$conexion = obtenerConexion();

// Recoger datos de entrada
$dni = $_POST['dni'];

// SQL
$sql = "DELETE FROM entrenadores WHERE dni = $dni;";

$resultado = mysqli_query($conexion, $sql);

if (mysqli_errno($conexion) != 0) {
    $numerror = mysqli_errno($conexion);
    $descrerror = mysqli_error($conexion);

    // Prototipo responder($datos,$ok,$mensaje,$conexion)
    responder(null, true, "Se ha producido un error número $numerror que corresponde a: $descrerror <br>", $conexion);

} else {
    // responder(datos, error, mensaje, conexion)
    responder(null, false, "Entrenador borrado", $conexion);
}