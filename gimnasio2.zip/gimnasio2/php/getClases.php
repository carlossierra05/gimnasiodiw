<?php
require_once('config.php');
$conexion = obtenerConexion();


$sql = "SELECT * FROM clases";
$result = $conn->query($sql);

$clases = [];
while ($row = $result->fetch_assoc()) {
    $clases[] = $row;  
}

echo json_encode($clases);  
$conn->close();
?>
