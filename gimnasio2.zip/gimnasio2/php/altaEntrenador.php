<?php
include_once("config.php");
$conexion = obtenerConexion();

// Recoger datos JSON
$entrenador = json_decode($_POST['entrenador']);

$sql = "INSERT INTO entrenadores VALUES ('$entrenador->dni','$entrenador->nombre',$entrenador->edad,'$entrenador->fecha_nacimiento','$entrenador->enfoques');";

mysqli_query($conexion, $sql);

if (mysqli_errno($conexion) != 0) {
    $numerror = mysqli_errno($conexion);
    $descrerror = mysqli_error($conexion);

    // Prototipo responder($datos,$ok,$mensaje,$conexion)
    responder(null, false, "Se ha producido un error número $numerror que corresponde a: $descrerror <br>", $conexion);

} else {
    $error = false;

    $salas = $entrenador->salas;
    foreach ($salas as $sala) {
        $sql2 = "INSERT INTO entrenador_sala VALUES ('$entrenador->dni',$sala->id);";
        mysqli_query($conexion, $sql2);

        if (mysqli_errno($conexion) != 0) {
            $numerror = mysqli_errno($conexion);
            $descrerror = mysqli_error($conexion);
            $error = true;

            // Prototipo responder($datos,$ok,$mensaje,$conexion)
            responder(null, false, "Se ha producido un error número $numerror que corresponde a: $descrerror <br>", $conexion);
            break;
        }
    }

    if(!$error){
        $especialidades = $entrenador->especialidades;
        foreach ($especialidades as $especialidad) {
            $sql3 = "INSERT INTO entrenador_especialidad VALUES ('$entrenador->dni',$especialidad->id);";
            mysqli_query($conexion, $sql3);

            if (mysqli_errno($conexion) != 0) {
                $numerror = mysqli_errno($conexion);
                $descrerror = mysqli_error($conexion);
                $error = true;

                // Prototipo responder($datos,$ok,$mensaje,$conexion)
                responder(null, false, "Se ha producido un error número $numerror que corresponde a: $descrerror <br>", $conexion);
                break;
            }
        }

        if(!$error){
            // Prototipo responder($datos,$ok,$mensaje,$conexion)
            responder(null, true, "Se ha insertado el entrenador", $conexion);
        }
    }
}
?>