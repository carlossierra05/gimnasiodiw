<?php
include_once("config.php");
// Habilitar el manejo de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conectar a la base de datos
$conn = new mysqli($host, $user, $password, $dbname);

// Comprobar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Comprobar que se ha enviado la solicitud con datos
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decodificar el JSON recibido
    $datosAlumno = json_decode($_POST["alumno"], true);

    // Validar que todos los campos estén presentes
    if (isset($datosAlumno["dni"], $datosAlumno["id_plan"], $datosAlumno["nombre"], $datosAlumno["edad"], $datosAlumno["fecha_nacimiento"])) {
        $dni = $datosAlumno["dni"];
        $id_plan = $datosAlumno["id_plan"];
        $nombre = $datosAlumno["nombre"];
        $edad = $datosAlumno["edad"];
        $fecha_nacimiento = $datosAlumno["fecha_nacimiento"];

        // Preparar la consulta SQL para actualizar el alumno
        $stmt = $conn->prepare("UPDATE alumnos SET id_plan = ?, nombre = ?, edad = ?, fecha_nacimiento = ? WHERE dni = ?");
        $stmt->bind_param("isiss", $id_plan, $nombre, $edad, $fecha_nacimiento, $dni);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            echo json_encode(["ok" => true, "mensaje" => "Alumno modificado correctamente"]);
        } else {
            echo json_encode(["ok" => false, "mensaje" => "Error al modificar el alumno: " . $stmt->error]);
        }

        // Cerrar la declaración preparada
        $stmt->close();
    } else {
        echo json_encode(["ok" => false, "mensaje" => "Datos incompletos para modificar el alumno"]);
    }
} else {
    echo json_encode(["ok" => false, "mensaje" => "Método no permitido"]);
}

// Cerrar la conexión
$conn->close();
?>
