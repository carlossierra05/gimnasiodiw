"use strict";

var oGym = new GYM();

//PARTE GRUPAL

const frmAltaAlumno = document.getElementById("frmAltaAlumno");
const frmListadoParam = document.getElementById("frmListadoParam");
const frmBorrarAlumno = document.getElementById("frmBorrarAlumno");
const frmListadoAlumnos = document.getElementById("frmListadoAlumnos");
const frmBuscarAlumno = document.getElementById("frmBuscarAlumno");
const frmModificarAlumno = document.getElementById("frmModificarAlumno");

const frmAltaEntrenador = document.getElementById("frmAltaEntrenador");
const frmListadoEntrenador = document.getElementById("frmListadoEntrenador");
const divListadoEntrenadoresFiltrados = document.getElementById('listadoEntrenadoresFiltrado');
const frmBorrarEntrenador = document.getElementById("frmBorrarEntrenador");

inicio();

function inicio() {
    document.querySelector("#mnuAltaAlumno").addEventListener("click", mostrarFormulario);
    document.querySelector("#mnuListadoAlumnoParam").addEventListener("click", mostrarFormulario);
    document.querySelector("#mnuBorrarAlumno").addEventListener("click", mostrarFormulario);
    document.querySelector("#mnuListadoAlumnos").addEventListener("click", mostrarFormulario);
    document.querySelector("#mnuBuscarAlumno").addEventListener("click", mostrarFormulario);
    document.querySelector("#mnuModificarAlumno").addEventListener("click", mostrarFormulario);

    document.querySelector("#mnuAltaEntrenador").addEventListener("click", mostrarFormulario);
    document.querySelector("#mnuListadoEntrenador").addEventListener("click", mostrarFormulario);
    document.querySelector("#mnuBorrarEntrenador").addEventListener("click", mostrarFormulario);

    frmAltaAlumno.btnAltaAlumno.addEventListener("click", altaAlumno);
    frmListadoParam.btnListadoParam.addEventListener("click", listadoParam);
    frmBorrarAlumno.btnBorrarAlumno.addEventListener("click", borrarAlumno);
    frmListadoAlumnos.btnListadoAlumnos.addEventListener("click", listadoAlumnos);
    frmBuscarAlumno.btnBuscarAlumno.addEventListener("click", buscarAlumno);
    frmModificarAlumno.btnModificarAlumno.addEventListener("click", modificarAlumno);

    frmAltaEntrenador.btnAltaEntrenador.addEventListener("click", altaEntrenador);
    frmListadoEntrenador.btnListadoEntrenador.addEventListener("click", listadoEntrenador);
    frmBorrarEntrenador.btnBorrarEntrenador.addEventListener("click", borrarEntrenador);
}

function ocultarFormularios() {
    // Asegúrate de que todos los formularios se oculten
    frmAltaAlumno.classList.add("d-none");
    frmListadoParam.classList.add("d-none");
    frmBorrarAlumno.classList.add("d-none");
    frmListadoAlumnos.classList.add("d-none");
    frmBuscarAlumno.classList.add("d-none");
    frmModificarAlumno.classList.add("d-none"); 


    frmAltaEntrenador.classList.add("d-none");
    frmListadoEntrenador.classList.add("d-none");
    frmBorrarEntrenador.classList.add("d-none");
    divListadoEntrenadoresFiltrados.classList.add('d-none');
}

function mostrarFormulario(oEvento) {
    ocultarFormularios(); // Llamar para ocultar todos los formularios

    // Solo se muestra el formulario correspondiente
    switch (oEvento.target.id) {
        case "mnuAltaAlumno":
            frmAltaAlumno.classList.remove("d-none");
            cargarDesplegable();  // Cargar planes
            break;
        case "mnuListadoAlumnoParam":
            frmListadoParam.classList.remove("d-none");
            break;
        case "mnuBorrarAlumno":
            frmBorrarAlumno.classList.remove("d-none");
            break;
        case "mnuListadoAlumnos":
            frmListadoAlumnos.classList.remove("d-none");
            break;
        case "mnuBuscarAlumno":
            frmBuscarAlumno.classList.remove("d-none");
            break;
        case "mnuModificarAlumno":
            frmModificarAlumno.classList.remove("d-none");
            break;
        case "mnuAltaClase":
            frmAltaClase.classList.remove("d-none");
            cargarClases(); // Cargar clases
            break;
        case "mnuAltaEntrenador":
            frmAltaEntrenador.classList.remove("d-none");
            cargarSalasEntrenador();
            cargarEspecialidadesEntrenador();
            break;
        case "mnuListadoEntrenador":
            frmListadoEntrenador.classList.remove("d-none");
            break;
        case "mnuBorrarEntrenador":
            frmBorrarEntrenador.classList.remove("d-none");
            break;
    }
}



//FUNCIONES DE CARLOS
async function altaAlumno() {
    let dni = frmAltaAlumno.dni.value.trim();
    let id_plan = frmAltaAlumno.lstPlanes.value;
    let nombre = frmAltaAlumno.nombre.value.trim();
    let edad = frmAltaAlumno.edad.value.trim();
    let fecha_nacimiento = frmAltaAlumno.fecha.value.trim();

    let alumno = new Alumno(dni, id_plan, nombre, edad, fecha_nacimiento);

    let respuesta = await oGym.altaAlumno(alumno);

    alert(respuesta.mensaje);

    if (respuesta.ok) {
        frmAltaAlumno.reset();
        ocultarFormularios();
    }
}

async function cargarDesplegable() {
    const respuesta = await oGym.getPlanes();

    if (respuesta.ok) {
        let optionsPlanes = "";
        for (let plan of respuesta.datos) {
            optionsPlanes += `<option value="${plan.id}">${plan.plan}</option>`;
        }

        frmAltaAlumno.lstPlanes.innerHTML = optionsPlanes;
    } else {
        alert("Error al recuperar las marcas");
    }
}

async function listadoParam() {
    let fechaInicio = frmListadoParam.txtFechaInicio.value.trim();
    let fechaFin = frmListadoParam.txtFechaFin.value.trim();

    const ventana = open("listado_alumnos.html");

    ventana.addEventListener("load", async () => {
        const listado = await oGym.listadoAlumno(fechaInicio, fechaFin);
        ventana.document.querySelector("#listado").innerHTML = listado;
    });
}

async function listadoAlumnos() {
    const ventana = open("listado_alumnos.html");

    ventana.addEventListener("load", async () => {
        const listado = await oGym.listarTodosAlumnos();
        ventana.document.querySelector("#listado").innerHTML = listado;
    });
}



async function borrarAlumno() {
    let dni = frmBorrarAlumno.txtDni.value.trim();

    if (!dni) {
        alert("Por favor, introduce un DNI válido.");
        return;
    }

    const respuesta = await oGym.borrarAlumno(dni);

    alert(respuesta.mensaje);

    if (respuesta.ok) {
        frmBorrarAlumno.reset();
    }
}

async function buscarAlumno() {
    // Obtener el DNI ingresado en el formulario
    let dni = frmBuscarAlumno.txtDni.value.trim();

    // Validar que el DNI no esté vacío
    if (!dni) {
        alert("Por favor, introduce un DNI válido.");
        return;
    }

    // Llamar al método `buscarAlumnoPorDni` de la clase GYM
    const respuesta = await oGym.buscarAlumnoPorDni(dni);

    if (respuesta.ok) {
        // Si se encuentra el alumno, mostrar los datos en un formato amigable
        const alumno = respuesta.datos;
        let detalles = `
            <h2>Alumno encontrado:</h2>
            <p><strong>DNI:</strong> ${alumno.dni}</p>
            <p><strong>Nombre:</strong> ${alumno.nombre}</p>
            <p><strong>Plan:</strong> ${alumno.plan}</p>
            <p><strong>Edad:</strong> ${alumno.edad}</p>
            <p><strong>Fecha de Nacimiento:</strong> ${alumno.fecha_nacimiento}</p>
        `;
        frmBuscarAlumno.querySelector("#resultadoBusqueda").innerHTML = detalles;
    } else {
        // Si no se encuentra el alumno, mostrar el mensaje de error
        alert(respuesta.mensaje);
        frmBuscarAlumno.querySelector("#resultadoBusqueda").innerHTML = "";
    }
}

async function modificarAlumno() {
    // Obtener el DNI ingresado en el formulario
    let dni = frmModificarAlumno.txtDni.value.trim();

    // Validar que el DNI no esté vacío
    if (!dni) {
        alert("Por favor, introduce un DNI válido.");
        return;
    }

    // Llamar al método `buscarAlumnoPorDni` para obtener los datos actuales del alumno
    const respuesta = await oGym.buscarAlumnoPorDni(dni);

    if (respuesta.ok) {
        // Si se encuentra el alumno, mostrar los datos en el formulario para que se puedan modificar
        const alumno = respuesta.datos;
        
        // Rellenar el formulario con los datos del alumno
        frmModificarAlumno.nombre.value = alumno.nombre;
        frmModificarAlumno.edad.value = alumno.edad;
        frmModificarAlumno.fecha.value = alumno.fecha_nacimiento;
        frmModificarAlumno.lstPlanes.value = alumno.id_plan;

        // Mostrar el formulario de modificación
        frmModificarAlumno.classList.remove("d-none");

        // Actualizar el botón para enviar la solicitud de modificación
        frmModificarAlumno.btnModificarAlumno.addEventListener("click", async () => {
            // Recoger los nuevos valores del formulario
            let nuevoNombre = frmModificarAlumno.nombre.value.trim();
            let nuevaEdad = frmModificarAlumno.edad.value.trim();
            let nuevaFechaNacimiento = frmModificarAlumno.fecha.value.trim();
            let nuevoPlan = frmModificarAlumno.lstPlanes.value;

            // Crear un objeto con los datos del alumno modificados
            let alumnoModificado = new Alumno(dni, nuevoPlan, nuevoNombre, nuevaEdad, nuevaFechaNacimiento);

            // Llamar al método `modificarAlumno` de oGym para enviar los cambios
            const respuestaModificacion = await oGym.modificarAlumno(alumnoModificado);

            alert(respuestaModificacion.mensaje);

            // Si la modificación es exitosa, ocultar el formulario
            if (respuestaModificacion.ok) {
                frmModificarAlumno.reset();
                ocultarFormularios();
            }
        });
    } else {
        // Si no se encuentra el alumno, mostrar el mensaje de error
        alert(respuesta.mensaje);
    }
}







//FUNCIONES DE ALMUDENA


document.getElementById('btnAltaClase').addEventListener('click', function () {
    const idClase = document.getElementById('dni').value;
    const tipo = document.getElementById('lstClases').value;
    const horario = document.getElementById('horarioClase').value;
    const idEntrenador = document.getElementById('idEntrenador').value;
    const sala = document.getElementById('salaClase').value;

    // Crear una instancia de la clase Clase
    const nuevaClase = new Clase(idClase, tipo, horario, idEntrenador, sala);

    // Enviar la nueva clase al servidor (por ejemplo, con AJAX)
    fetch('api/altaClase', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(nuevaClase.toJSON()) // Convertir el objeto a JSON
    })
        .then(response => response.json())
        .then(data => {
            console.log('Clase registrada:', data);
            // Aquí podrías mostrar un mensaje de éxito al usuario
        })
        .catch(error => console.error('Error al registrar la clase:', error));
});

document.getElementById('btnBorrarClase').addEventListener('click', function () {
    const idClase = document.getElementById('txtIDClase').value;

    // Crear una instancia de la clase Clase para representarla
    const claseABorrar = new Clase(idClase);

    // Enviar al servidor para eliminar la clase
    fetch('api/borrarClase', {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id: claseABorrar.id })
    })
        .then(response => response.json())
        .then(data => {
            console.log('Clase eliminada:', data);
            // Aquí podrías mostrar un mensaje de éxito al usuario
        })
        .catch(error => console.error('Error al borrar la clase:', error));
});


document.getElementById('btnBuscarClase').addEventListener('click', function () {
    const idClase = document.getElementById('txtidClase').value;

    // Buscar la clase por ID
    fetch(`api/buscarClase?id=${idClase}`)
        .then(response => response.json())
        .then(data => {
            const claseEncontrada = new Clase(data.id, data.tipo, data.horario, data.idEntrenador, data.sala);
            document.getElementById('resultadoBusquedaClase').innerHTML = `
                <p>Clase encontrada: ${claseEncontrada.tipo} - ${claseEncontrada.horario}</p>
            `;
        })
        .catch(error => console.error('Error al buscar la clase:', error));
});



// document.addEventListener("DOMContentLoaded", () => {
//     // Elementos del DOM
//     const frmAltaClase = document.getElementById("frmAltaClase");
//     const frmBorrarClase = document.getElementById("frmBorrarClase");
//     const frmListadoClases = document.getElementById("frmListadoClases");
//     const frmBuscarClase = document.getElementById("frmBuscarClase");

//     const btnAltaClase = document.getElementById("btnAltaClase");
//     const btnBorrarClase = document.getElementById("btnBorrarClase");
//     const btnListadoClases = document.getElementById("btnListadoClases");
//     const btnBuscarClase = document.getElementById("btnBuscarClase");

//     const lstClases = document.getElementById("lstClases");
//     const resultadoBusquedaClase = document.getElementById("resultadoBusquedaClase");

//     // Menú navegación
//     const mnuAltaClase = document.getElementById("mnuAltaClase");
//     const mnuListadoClase = document.getElementById("mnuListadoClase");
//     const mnuBorrarClase = document.getElementById("mnuBorrarClase");
//     const mnuBuscarClase = document.getElementById("mnuBuscarClase");

//     // Función para mostrar el formulario seleccionado
//     function mostrarFormulario(formulario) {
//         [frmAltaClase, frmBorrarClase, frmListadoClases, frmBuscarClase].forEach((frm) => {
//             frm.classList.add("d-none");
//         });
//         formulario.classList.remove("d-none");
//     }

//     // Cargar clases en el select al cargar el formulario de Alta Clase
//     async function cargarClases() {
//         const response = await obtenerClases(); // Función definida en ajax.js
//         lstClases.innerHTML = '<option value="">Seleccione una clase</option>';
//         response.forEach(clase => {
//             const option = document.createElement("option");
//             option.value = clase.id;
//             option.textContent = clase.nombre;
//             lstClases.appendChild(option);
//         });
//     }

//     // Eventos del menú
//     mnuAltaClase.addEventListener("click", () => {
//         mostrarFormulario(frmAltaClase);
//         cargarClases();
//     });

//     mnuListadoClase.addEventListener("click", () => mostrarFormulario(frmListadoClases));
//     mnuBorrarClase.addEventListener("click", () => mostrarFormulario(frmBorrarClase));
//     mnuBuscarClase.addEventListener("click", () => mostrarFormulario(frmBuscarClase));

//     // Eventos de los botones
//     btnAltaClase.addEventListener("click", async () => {
//         const idClase = frmAltaClase.idClase.value;
//         const claseSeleccionada = lstClases.value;

//         if (!idClase || !claseSeleccionada) {
//             alert("Debe completar todos los campos.");
//             return;
//         }

//         const resultado = await altaClase({ id: idClase, clase: claseSeleccionada }); // Función definida en ajax.js
//         alert(resultado ? "Clase añadida correctamente" : "Error al añadir la clase");
//     });

//     btnBorrarClase.addEventListener("click", async () => {
//         const idClase = frmBorrarClase.txtIDClase.value;

//         if (!idClase) {
//             alert("Debe indicar el ID de la clase.");
//             return;
//         }

//         const resultado = await borrarClase(idClase); // Función definida en ajax.js
//         alert(resultado ? "Clase borrada correctamente" : "Error al borrar la clase");
//     });

//     btnListadoClases.addEventListener("click", async () => {
//         const clases = await listarClases(); // Función definida en ajax.js
//         let html = "<ul>";
//         clases.forEach(clase => {
//             html += `<li>ID: ${clase.id} - Nombre: ${clase.nombre}</li>`;
//         });
//         html += "</ul>";
//         frmListadoClases.innerHTML = html;
//     });

//     btnBuscarClase.addEventListener("click", async () => {
//         const idClase = frmBuscarClase.txtidClase.value;

//         if (!idClase) {
//             alert("Debe indicar el ID de la clase.");
//             return;
//         }

//         const clase = await buscarClase(idClase); // Función definida en ajax.js
//         resultadoBusquedaClase.textContent = clase ? `Clase encontrada: ${clase.nombre}` : "Clase no encontrada";
//     });
// });





// function cargarClases() {
//     fetch('obtener_clases.php')
//         .then(response => response.json())
//         .then(clases => {
//             var select = document.getElementById('lstClases');
//             select.innerHTML = '';

//             var option = document.createElement('option');
//             option.value = '';
//             option.textContent = 'Seleccione una clase';
//             select.appendChild(option);

//             clases.forEach(function(clase) {
//                 var option = document.createElement('option');
//                 option.value = clase.id_clase;
//                 option.textContent = clase.tipo;
//                 select.appendChild(option);
//             });
//         })
//         .catch(error => {
//             alert('Error al cargar las clases');
//             console.error(error);
//         });
// }
// async function cargarFormularioSala() {
//     const respuesta = await oGym.getClases();
//     if (respuesta.ok) {
//         let optionsClases = "";
//         for (let clase of respuesta.datos) {
//             optionsClases += `<option value="${clase.id_clase}">${clase.tipo}</option>`;
//         }

//         frmListadoClases.lstClases.innerHTML=optionsClases;
//     } else {
//         alert("Error al recuperar las clases");
//     }
// }

// document.addEventListener('DOMContentLoaded', function() {
//     cargarClases();
// });






//FUNCIONES DE SERGIO
async function altaEntrenador(){
    let dni = frmAltaEntrenador.dniE.value.trim();
    let nombre = frmAltaEntrenador.nombreE.value.trim();
    let edad = frmAltaEntrenador.edadE.value.trim();
    let fecha_nacimiento = frmAltaEntrenador.fechaE.value.trim();
    let enfoques = frmAltaEntrenador.lstEnfoques.value.trim();
    
    let salas = [];
    document.getElementById("lstSalas").querySelectorAll("input[type='checkbox']:checked").forEach(sala =>{
        let textoSala = document.getElementById("lstSalas").querySelector("#txtSala"+sala.value).textContent;
        salas.push(new Sala(sala.value,textoSala));
    });


    let especialidades = [];
    document.getElementById("lstEspecialidades").querySelectorAll("input[type='checkbox']:checked").forEach(especialidad =>{
        let textoEspecialidad = document.getElementById("lstEspecialidades").querySelector("#txtEspecialidad"+especialidad.value).textContent;
        especialidades.push(new Especialidad(especialidad.value,textoEspecialidad));
    });

    let entrenador = new Entrenador(dni, salas, especialidades, enfoques, nombre, edad, fecha_nacimiento);
    console.log(entrenador);

    let respuesta = await oGym.altaEntrenador(entrenador);

    alert(respuesta.mensaje);

    if (respuesta.ok) {
        frmAltaEntrenador.reset();
        ocultarFormularios();
    }
    
}

async function cargarSalasEntrenador() {
    const respuesta = await oGym.getSalas();

    if (respuesta.ok) {
        let checkBoxSalas = "";
        for (let sala of respuesta.datos) {
            checkBoxSalas += `<div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="inlineCheckboxSala${sala.id}" value="${sala.id}">
                                <label class="form-check-label" id="txtSala${sala.id}" for="inlineCheckboxSala${sala.id}">${sala.sala}</label>
                             </div>`;
        }

        document.getElementById("lstSalas").innerHTML = checkBoxSalas;

        cargarEventosSalas();
    } else {
        alert("Error al recuperar las salas");
    }
}

async function cargarEventosSalas(){
    const listadoSalas = document.getElementById("lstSalas");
    const numeroMaximoSeleccionable = 2;

    listadoSalas.querySelectorAll("input[type='checkbox']").forEach(element =>{
        element.addEventListener("change", function(){
            const seleccionados = listadoSalas.querySelectorAll("input[type='checkbox']:checked").length;
            if(seleccionados == numeroMaximoSeleccionable){
                listadoSalas.querySelectorAll("input[type='checkbox']:not(:checked)").forEach(checkb=> {
                    checkb.disabled = true;
                });
            } else {
                listadoSalas.querySelectorAll("input[type='checkbox']:not(:checked)").forEach(checkb=> {
                    checkb.disabled = false;
                });
            }
        });
    });
}

async function cargarEspecialidadesEntrenador() {
    const respuesta = await oGym.getEpecialidades();

    if (respuesta.ok) {
        let checkBoxEspecialidades = "";
        for (let especialidad of respuesta.datos) {
            checkBoxEspecialidades += `<div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="inlineCheckboxEspecialidad${especialidad.id}" value="${especialidad.id}">
                                <label class="form-check-label" id="txtEspecialidad${especialidad.id}" for="inlineCheckboxEspecialidad${especialidad.id}">${especialidad.especialidad}</label>
                             </div>`;
        }

        document.getElementById("lstEspecialidades").innerHTML = checkBoxEspecialidades;

        cargarEventosEspecialidades();
    } else {
        alert("Error al recuperar las especialidades");
    }
}

async function cargarEventosEspecialidades(){
    const listadoEspecialidades = document.getElementById("lstEspecialidades");
    const numeroMaximoSeleccionable = 2;
    
    listadoEspecialidades.querySelectorAll("input[type='checkbox']").forEach(element =>{
        element.addEventListener("change", function(){
            const seleccionados = listadoEspecialidades.querySelectorAll("input[type='checkbox']:checked").length;
            if(seleccionados == numeroMaximoSeleccionable){
                listadoEspecialidades.querySelectorAll("input[type='checkbox']:not(:checked)").forEach(checkb=> {
                    checkb.disabled = true;
                });
            } else {
                listadoEspecialidades.querySelectorAll("input[type='checkbox']:not(:checked)").forEach(checkb=> {
                    checkb.disabled = false;
                });
            }
        });
    });
}

async function listadoEntrenador(){
    divListadoEntrenadoresFiltrados.classList.add('d-none');
    let fechaInicio = frmListadoEntrenador.txtFechaInicioE.value.trim();
    let fechaFin = frmListadoEntrenador.txtFechaFinE.value.trim();

    const listado = await oGym.listadoEntrenador(fechaInicio, fechaFin);
    document.getElementById("listadoEntrenadoresFiltrado").innerHTML = listado;
    divListadoEntrenadoresFiltrados.classList.remove('d-none');
    
}

async function borrarEntrenador(oEvento){
    let boton = oEvento.target;
    let dni = boton.dataset.dni;

    let respuesta = await oGym.borrarEntrenador(dni);

    alert(respuesta.mensaje);

    if (!respuesta.error) { // Si NO hay error
        // Borrado de la tabla html
        document.querySelector("#listado").innerHTML = "Borrado ";
    }
}